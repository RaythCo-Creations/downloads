# Player Head Addon + Creator
# Created 27/01/2023 [dd/mm/yyyy]
# Author: Rayth
# Version: 1.0.0
# Made for Minecraft Bedrock Edition 1.19.50
# For more information, visit http://www.raythnetwork.co.uk

README
---------------

Pack Contents
--------------
- RNPlayerHeads.exe - this nifty application creates the addon for you.
- input folder - Files required by the software to create your addon.

Using the Software
------------------
* First Time
- If this is your first time, the software will create a folder called "skins". Once it does this, you will need to place player skin files inside this folder for the pack to be generated.
Note: only 64x64 skins are supported at this time!

* Not-First Time
- If you've previously used this software and want to use different skins from before, you need to either delete the skin folder, or all skin files in the folder then put new files in.

After skin files are in the folder, press any key in the software (or re-run it if you closed it) and you will be asked 2 questions. 
The first is how many diamonds players will pay the Wandering Trader per head.
The second, is how many different heads the Wandering Trader will offer each time he spawns. This can be anywhere from 1-Number of skins. So If you had 30 skins, you could put any number from 1-30. If you put more, the wandering trader will have 0 trades at all.

After inputting this information, the software will create a new file called RN PlayerHeads.mcaddon then the console window will close.


Installing the Pack into Minecraft
-------------------
To load into minecraft, simply double click the MCAddon file that was generated and it should import into minecraft. Alternatively, you can right click and open with minecraft.
Then you create a new world, enable "Holiday Creator Features" experimental mode. THIS IS REQUIRED OR YOUR HEADS WILL NOT SHOW UP.
Then enable either the RN Player Heads resource or behavior pack (the other will automatically enable)

Create your world, and find a wandering trader :)

If you're in creative, just search "Head" in the creative inventory.


FAQ
-----------
Q) My heads aren't showing up!
A) Please join my discord for support with this. http://discord.gg/rayth

Q) My Wandering trader has 0 trades at all!
A) Make sure the number of trades you put for him to show is not more than the number of skins you submitted

Q) How do I add more heads in the future?
A) Just re-make a new pack and change which one is enabled on the world. A new UUID is generated for each pack when it's made.


HELP & SUPPORT
------------
For help, please join http://discord.gg/rayth


LINKS
-------------
Discord: http://discord.gg/rayth
Youtube: http://youtube.com/raythgaming
Website: http://raythnetwork.co.uk